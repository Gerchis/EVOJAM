﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class Powerups : InterfaceEffector
{
    
    public void activate()
    {

    }

    public int precio;
    public PowerupsName pwrNombreEnum;
    public string nombre;
    public string descripcion;    
    public int cantidad;

    //Valor interno de control
    public int noticiaAfectada;
}
